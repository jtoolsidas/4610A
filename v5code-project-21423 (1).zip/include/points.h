class Points{
  public:
  Points(float x, float y);
  Points vectorToHelper(float x, float y);
  Points vectorTo(Points p);
  float distTo(float x , float y);
  float distTo(Points target);
  float angleToHelper(float x , float y);
  float angleTo(Points target);

  private:
  float xPos;
  float yPos; 
};