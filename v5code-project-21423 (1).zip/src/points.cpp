#include "points.h"
#include <cmath>

Points::Points(float x, float y)
{
  xPos = x;
  yPos = y;
}

//returns unit vector
Points Points::vectorToHelper(float x, float y)
{
  //distance to new x
  x = xPos - x;
  //distance to new y
  y = yPos - y;

  float magnitude = sqrt((pow(x,2) + pow(y,2)));

  return Points(x/magnitude, y/magnitude);
}

Points Points::vectorTo(Points point){
  return vectorToHelper(point.xPos, point.yPos);
}

float Points::distTo(float x, float y)
{
  return sqrt((pow(x,2) + pow(y,2)));
}

float Points::angleToHelper(float x, float y)
{
  float deltaX = x - xPos;
  float deltaY = y = yPos;

  //tan of change in y over change in x gets angle (converts from radians to degrees)
  //might have to add 90 for debugging purposes
  float degree = ((180 * atan2(deltaY, deltaX)) / M_PI);
  return degree;
}

float Points::angleTo(Points point)
{
  return angleToHelper(point.xPos, point.yPos);
}