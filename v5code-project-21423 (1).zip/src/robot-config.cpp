#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor frontRightMotor = motor(PORT17, ratio18_1, false);
motor frontLeftMotor = motor(PORT18, ratio18_1, false);
inertial inertia = inertial(PORT13);
line lineTrackerBL = line(Brain.ThreeWirePort.A);
line lineTrackerBR = line(Brain.ThreeWirePort.B);
line lineTrackerFL = line(Brain.ThreeWirePort.C);
line lineTrackerFR = line(Brain.ThreeWirePort.D);
line lineTrackerMB = line(Brain.ThreeWirePort.E);
line lineTrackerMF = line(Brain.ThreeWirePort.F);
motor rollerSpinner = motor(PORT9, ratio18_1, false);
motor backRightMotor = motor(PORT1, ratio18_1, true);
motor backLeftMotor = motor(PORT8, ratio18_1, true);
controller Controller1 = controller(primary);
digital_out pneumatic = digital_out(Brain.ThreeWirePort.H);
rotation yEncoder = rotation(PORT7, true);
rotation xEncoder = rotation(PORT10, false);
motor indexer = motor(PORT14, ratio18_1, false);
optical opticalSensor = optical(PORT21);
motor flywheel = motor(PORT4, ratio18_1, false);
motor intake = motor(PORT6, ratio6_1, false);
digital_out pneum2 = digital_out(Brain.ThreeWirePort.G);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}