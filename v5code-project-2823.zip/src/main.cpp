/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// frontLeftWheel       motor         18              
// frontRightWheel      motor         17              
// backLeftWheel        motor         8               
// backRightWheel       motor         1               
// Optical2             optical       21              
// InternalSensor       inertial      13              
// HorizontalEncoder    rotation      10              
// LeftEncoder          rotation      7               
// intakeRolyPoly       motor         6               
// flywheel             motor         4               
// indexer              motor         14              
// pneu                 digital_out   H               
// roller               motor         9               
// ---- END VEXCODE CONFIGURED DEVICES ----


#include "vex.h"
using namespace vex;
// A global instance of competition
competition Competition;
task opticalTask;
int opticalValues(){
while(1){
// if (Optical2.isNearObject()) {
//   //Brain.Screen.print("Object Detected");
//   Brain.Screen.newLine();
//   Brain.Screen.print("Hue: ");
//   Brain.Screen.print("%.2f", Optical2.hue());
//   Brain.Screen.newLine();
//   Brain.Screen.print("Detects a red object?: ");
//   if(Optical2.color() == red){
//      Brain.Screen.newLine();
//      Brain.Screen.print("Detects a red object");
//   }
//   else if(Optical2.color() == blue){
//      Brain.Screen.newLine();
//      Brain.Screen.print("Detects a blue object");
//   }
//  Brain.Screen.print("%s", Optical2.color() == red ? "TRUE" : "FALSE");
//  Brain.Screen.newLine();
//  Brain.Screen.print("Detects a blue object?: ");
//  Brain.Screen.print("%s", Optical2.color() == blue ? "TRUE" : "FALSE");
//  Brain.Screen.newLine();
//} else {
//Brain.Screen.newLine();
//Brain.Screen.print("No Object Detected");
}
}






task printTask;
int printValues(){
while(1) {
//Brain.Screen.clearScreen();
//Brain.Screen.printAt(1, 20, "rotation: %f degrees", InternalSensor.rotation(degrees));
//Brain.Screen.printAt(1,40, "left wheel: %f", frontLeftWheel.position(deg));
//Brain.Screen.printAt(1,60, "right wheel: %f", frontRightWheel.position(deg));
//Brain.Screen.printAt(1,80, "vertical encoder: %f", LeftEncoder.position(degrees));
//Brain.Screen.printAt(1,100, "horizontal encoder: %f", HorizontalEncoder.position(degrees));
task::sleep(100);
}
}
//SETTINGS
//Utilize these three variables to make sure they are reading correctly.
//The horizontal encoder should be positive if you push the robot laterally to the right
//The vertical encoders should be positive if you pusht the robot laterally forward
//Rotating the robot clockwise should yield a positive degree value
//NOTE: The recommended position of the vertical encoders(left and right) should be located at center of mass
bool flipLeftEncoder = true;
//bool flipRightEncoder = true;
bool flipHorizontalEncoder = false;
bool flipRotations = true;
//This is how many miliseconds every cycle (recommended is 15)
int milisecondStepTime = 15;
//This is something you should utilize to convert the horizontal encoder distance to match the vertical encoder distance
//Grab a ruler, and push the robot 20 inches straight forward, then record the average vertical value (Example: 51269)
//Reset, Grab a ruler, and push the robot 20 inches to the right, then record the horizontal encoder value (Example: 10532)
//You will need to convert it such that the horizontal matches for the same distance, so the multiplier will be horizontal(10532)/vertical(51269)
//And that number will be the ratio (10532/51269 = 0.2054262809885116)
double verticalToHorizontalRatio = 1.006594;
//Because we can average the vertical encoders while turning, it will not show a change
//But for the horizontal encoders, it will assume the robot is laterally strafing, which is not correct
//We fix this by applying a multiplier compensation such that we will negate it using the inertial sensor
//Reset your robot, make sure everything is calibrated
//Rotate your robot such that the inertial sensor reads 3600 degrees (i.e. rotate the robot 10 times for the sake of accuracy)
//Your horizontal encoder should have a value (Example: 231809)
//Divide that result by 3600 (231809/3600 = 64.3913888), and that number will be the value used
double rotateNegateHorizontalRatio = -1.1342787;
//This is utilized to convert the ticks moved to actual inches
//Push the robot 20 inches forward (without turning it or pushing it strafe-wise)
//Get the average reading of the vertical encoders (Example: 253053)
//Divide the reading by 20 (253053/20 = 12,652.65), and put the multipler in this area
//This will convert it to inches
double posTranslationMultiplier = 20312.35;
//Inclusions added manually
// Include additional mathematical operations
#include <cmath>
//Functions added manually
// Waiting function that returns time actually waited (Credit to James Pearman (jpearman on VEXForum - https://www.vexforum.com/t/vexcode-sleep-help/82706/2?u=connor))
uint32_t wait( uint32_t time_mS ) {
uint64_t start = Brain.Timer.systemHighResolution();
this_thread::sleep_for(time_mS);
return (uint32_t)(Brain.Timer.systemHighResolution() - start);
}
// This converts degrees to radians
double getRadians(int degrees){
return ( degrees * M_PI ) / 180 ;
}
//Initialized variables for usage
// Include additional mathematical operations
double lastVerticalPosLocal = 0.0;
double lastHorizontalPosLocal = 0.0;
double XPos = 0.0;
double YPos = 0.0;
void driveControlForwards(double inches) {
inches = -inches /3.3;
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
double targetDegrees = (inches*360)/4 *-1;  // 4 inch wheel
double leftValue = frontLeftWheel.position(degrees);
double rightValue = frontRightWheel.position(degrees);
double leftError;
double rightError;
double leftLastError = targetDegrees - leftValue;
double rightLastError = targetDegrees - rightValue;
double leftInt = 0;
double rightInt = 0;
double leftDeriv = 0;
double rightDeriv = 0;
double leftPower;
double rightPower;
double leftKp = 0.2;
double leftKi = 0;
double leftKd = 0;
double rightKp = 0.2;
double rightKi = 0;
double rightKd = 0;
int dT = 15;
while(true) {
leftValue = -frontLeftWheel.position(degrees);     //set values from sensor
rightValue = -frontRightWheel.position(degrees);
leftError = leftValue - targetDegrees;    //set errors
rightError = rightValue - targetDegrees;
if(fabs(leftError) < 15) {   //exit condition
break;
}
leftInt += (leftError/dT);             //update integers
rightInt += (rightError/dT);
leftDeriv = leftError - leftLastError;    //set derivative
rightDeriv = rightError - rightLastError;
leftPower = (leftError * leftKp) + (leftInt * leftKi) - (leftDeriv * leftKd);           //update motor powers
rightPower = (rightError * rightKp) + (rightInt * rightKi) - (rightDeriv * rightKd);
frontLeftWheel.spin(forward, leftPower/0.5, percent);   //spin motors at output speed
frontRightWheel.spin(forward, rightPower/0.5, percent);
backLeftWheel.spin(forward, leftPower/0.5, percent);
backRightWheel.spin(forward, rightPower/0.5, percent);
leftLastError = leftError;      //update last error values
rightLastError = rightError;
Brain.Screen.printAt(1,40, "left wheel: %f", frontLeftWheel.position(deg));
Brain.Screen.printAt(1,60, "right wheel: %f", frontRightWheel.position(deg));
this_thread::sleep_for(dT);       //sleep
}
frontLeftWheel.stop();        //after loop is broken, stop motors
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}
void driveControlStrafe(double inches) {
inches = -inches /3.3;
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
double targetDegrees = (inches*360)/4 *-1;  // 4 inch wheel
// double leftValue = frontLeftWheel.position(degrees);
// double rightValue = -frontLeftWheel.position(degrees);
double leftValue = (frontLeftWheel.position(degrees));
double rightValue = -(frontLeftWheel.position(degrees));
double leftError;
double rightError;
double leftLastError = targetDegrees - leftValue;
double rightLastError = targetDegrees - rightValue;
double leftInt = 0;
double rightInt = 0;
double leftDeriv = 0;
double rightDeriv = 0;
double leftPower;
double rightPower;
double leftKp = 0.2;
double leftKi = 0;
double leftKd = 0;
double rightKp = 0.2;
double rightKi = 0;
double rightKd = 0;
int dT = 50;
while(true) {
leftValue = frontLeftWheel.position(degrees);     //set values from sensor
rightValue = -frontRightWheel.position(degrees);
leftError = leftValue - targetDegrees;    //set errors
rightError = rightValue - targetDegrees;
if(fabs(leftError) < 15 || fabs(rightError) < 15) {   //exit condition
break;
}
leftInt += (leftError/dT);             //update integers
rightInt += (rightError/dT);
leftDeriv = leftError - leftLastError;    //set derivative
rightDeriv = rightError - rightLastError;
leftPower = (leftError * leftKp) + (leftInt * leftKi) - (leftDeriv * leftKd);           //update motor powers
rightPower = (rightError * rightKp) + (rightInt * rightKi) - (rightDeriv * rightKd);
frontLeftWheel.spin(reverse, leftPower, percent);   //spin motors at output speed
frontRightWheel.spin(forward, rightPower, percent);
backLeftWheel.spin(forward, leftPower, percent);
backRightWheel.spin(reverse, rightPower, percent);
leftLastError = leftError;      //update last error values
rightLastError = rightError;
this_thread::sleep_for(dT);       //sleep
}
frontLeftWheel.stop();        //after loop is broken, stop motors
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}

void turning(double degree) {
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
while(frontLeftWheel.position(degrees)<80);
frontLeftWheel.spin(forward);
frontRightWheel.spin(forward);
backLeftWheel.spin(reverse);
backRightWheel.spin(reverse);
frontLeftWheel.stop();
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}


void driveControlStrafeEdited(double inches) {
inches = -inches /3.3;
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
double targetDegrees = (inches*360)/4 *-1;  // 4 inch wheel
double leftValue = frontLeftWheel.position(degrees);
double rightValue = backRightWheel.position(degrees);
double leftValue2 = (frontLeftWheel.position(degrees) + backRightWheel.position(degrees))/2;
double rightValue2 = (frontRightWheel.position(degrees) + backLeftWheel.position(degrees))/2;
double leftError;
double rightError;
double leftLastError = targetDegrees - leftValue;
double rightLastError = targetDegrees - rightValue;
double leftInt = 0;
double rightInt = 0;
double leftDeriv = 0;
double rightDeriv = 0;
double leftPower;
double rightPower;
double leftKp = 0.1;
double leftKi = 0;
double leftKd = 0;
double rightKp = 0.1;
double rightKi = 0;
double rightKd = 0;
int dT = 50;
while(true) {
leftValue = frontLeftWheel.position(degrees);     //set values from sensor
rightValue = -frontRightWheel.position(degrees);
leftError = leftValue - targetDegrees;    //set errors
rightError = rightValue - targetDegrees;
if(fabs(leftError) < 15 || fabs(rightError) < 15) {   //exit condition
break;
}
leftInt += (leftError/dT);             //update integers
rightInt += (rightError/dT);
leftDeriv = leftError - leftLastError;    //set derivative
rightDeriv = rightError - rightLastError;
leftPower = (leftError * leftKp) + (leftInt * leftKi) - (leftDeriv * leftKd);           //update motor powers
rightPower = (rightError * rightKp) + (rightInt * rightKi) - (rightDeriv * rightKd);
frontLeftWheel.spin(reverse, leftPower, percent);   //spin motors at output speed
frontRightWheel.spin(forward, rightPower, percent);
backLeftWheel.spin(forward, leftPower, percent);
backRightWheel.spin(reverse, rightPower, percent);
leftLastError = leftError;      //update last error values
rightLastError = rightError;
this_thread::sleep_for(dT);       //sleep
}
frontLeftWheel.stop();        //after loop is broken, stop motors
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}
void driveControlBackwards(double inches) {
inches = inches /3.3;
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
double targetDegrees = (inches*360)/4 *-1;  // 4 inch wheel
double leftValue = frontLeftWheel.position(degrees);
double rightValue = -frontLeftWheel.position(degrees);
double leftError;
double rightError;
double leftLastError = targetDegrees - leftValue;
double rightLastError = targetDegrees - rightValue;
double leftInt = 0;
double rightInt = 0;
double leftDeriv = 0;
double rightDeriv = 0;
double leftPower;
double rightPower;
double leftKp = 0.05;
double leftKi = 0;
double leftKd = 0;
double rightKp = 0.05;
double rightKi = 0;
double rightKd = 0;
int dT = 50;
while(true) {
leftValue = -frontLeftWheel.position(degrees);     //set values from sensor
rightValue = -frontRightWheel.position(degrees);
leftError = leftValue - targetDegrees;    //set errors
rightError = rightValue - targetDegrees;
if(fabs(leftError) < 15 && fabs(rightError) < 15) {   //exit condition
break;
}
leftInt += (leftError/dT);             //update integers
rightInt += (rightError/dT);
leftDeriv = leftError - leftLastError;    //set derivative
rightDeriv = rightError - rightLastError;
leftPower = (leftError * leftKp) + (leftInt * leftKi) - (leftDeriv * leftKd);           //update motor powers
rightPower = (rightError * rightKp) + (rightInt * rightKi) - (rightDeriv * rightKd);
frontLeftWheel.spin(forward, leftPower/0.5, percent);   //spin motors at output speed
frontRightWheel.spin(forward, rightPower/0.5, percent);
backLeftWheel.spin(forward, leftPower/0.5, percent);
backRightWheel.spin(forward, rightPower/0.5, percent);
leftLastError = leftError;      //update last error values
rightLastError = rightError;
this_thread::sleep_for(dT);       //sleep
}
frontLeftWheel.stop();        //after loop is broken, stop motors
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}
double gyroValue;
task gyroTask;
int gyroReturn() {
int rotations = 0;
double lastGyroValue = InternalSensor.heading(degrees);
while(true) {
if(InternalSensor.heading(degrees) > 350 && lastGyroValue < 10) {
rotations--;
} else if(InternalSensor.heading(degrees) < 10 && lastGyroValue > 350) {
rotations++;
}
if(rotations < 0) {
gyroValue = (360*rotations) + InternalSensor.heading(degrees);
} else {
gyroValue = (360*rotations) + InternalSensor.heading(degrees);
}
lastGyroValue = InternalSensor.heading(degrees);
this_thread::sleep_for(10);
}
//return 0;
}
double leftDeriv;
double rightDeriv;
double leftError;
double rightError;
double leftInt;
double rightInt;
void driveControlTurnGyro(double degs) {
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
//double targetDegrees = (degs*360)/(4*3.1415*9.5);
double targetDegrees = gyroValue + degs;
double leftValue = -frontLeftWheel.position(degrees);
double rightValue = -frontRightWheel.position(degrees);
double leftError;
double rightError;
double leftLastError = targetDegrees - leftValue;
double rightLastError = targetDegrees - rightValue;    //CHANGED
double error;
double lastError;
double integer = 0;
double leftInt = 0;
double rightInt = 0;
double deriv = 0;
double leftDeriv = 0;
double rightDeriv = 0;
double leftPower;
double rightPower;
double leftKp = 0.05;
double leftKi = 0;
double leftKd = 0;
double rightKp = 0.05;
double rightKi = 0;
double rightKd = 0;
int dT = 20;
while(1) {
leftValue = frontLeftWheel.position(degrees);     //set values from sensor
rightValue = frontRightWheel.position(degrees);
leftError = targetDegrees - leftValue;    //set errors
rightError = targetDegrees - rightValue;       //CHANGED
error = targetDegrees - gyroValue;
if(fabs(error) < 15) {   //exit condition
break;
}
leftInt += (leftError/dT);             //update integers
rightInt += (rightError/dT);
integer += (error/dT);
deriv = error - lastError;
leftDeriv = leftError - leftLastError;    //set derivative
rightDeriv = rightError - rightLastError;
leftPower = (error * leftKp) + (integer * leftKi) - (deriv * leftKd);           //update motor powers
rightPower = (error * rightKp) + (integer * rightKi) - (deriv * rightKd);
frontLeftWheel.spin(fwd, leftPower, percent);   //spin motors at output speed
frontRightWheel.spin(fwd, rightPower, percent);
backLeftWheel.spin(reverse, leftPower, percent);
backRightWheel.spin(reverse, rightPower, percent);
lastError = error;
leftLastError = leftError;      //update last error values
rightLastError = rightError;
this_thread::sleep_for(dT);       //sleep
}
frontLeftWheel.stop();        //after loop is broken, stop motors
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}
void driveControlTurnLeft(double degs) {
degs = degs /3.3;
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
double targetDegrees = (degs*360)/4;  // 4 inch wheel
double leftValue = frontLeftWheel.position(degrees);
double rightValue = frontRightWheel.position(degrees);
double leftError;
double rightError;
double leftLastError = targetDegrees - leftValue;
double rightLastError = targetDegrees - rightValue;
double leftInt = 0;
double rightInt = 0;
double leftDeriv = 0;
double rightDeriv = 0;
double leftPower;
double rightPower;
double leftKp = 0.01;
double leftKi = 0;
double leftKd = 0;
double rightKp = 0.01;
double rightKi = 0;
double rightKd = 0;
int dT = 15;
while(true) {
leftValue = frontLeftWheel.position(degrees);     //set values from sensor
rightValue = frontRightWheel.position(degrees);
leftError = leftValue - targetDegrees;    //set errors
rightError = rightValue - targetDegrees;
if(fabs(leftError) < 15) {   //exit condition
break;
}
else if(fabs(rightError) < 15) {
break;
}
leftInt += (leftError/dT);             //update integers
rightInt += (rightError/dT);
leftDeriv = leftError - leftLastError;    //set derivative
rightDeriv = rightError - rightLastError;
leftPower = (leftError * leftKp) + (leftInt * leftKi) - (leftDeriv * leftKd);           //update motor powers
rightPower = (rightError * rightKp) + (rightInt * rightKi) - (rightDeriv * rightKd);
frontLeftWheel.spin(reverse, leftPower, percent);   //spin motors at output speed
frontRightWheel.spin(forward, rightPower, percent);
backLeftWheel.spin(reverse, leftPower, percent);
backRightWheel.spin(forward, rightPower, percent);
leftLastError = leftError;      //update last error values
rightLastError = rightError;
Brain.Screen.printAt(1,40, "left wheel: %f", frontLeftWheel.position(deg));
Brain.Screen.printAt(1,60, "right wheel: %f", frontRightWheel.position(deg));
this_thread::sleep_for(dT);       //sleep
}
frontLeftWheel.stop();        //after loop is broken, stop motors
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
}
//driveControlStrafe
void PIDODOMYPOS(double yWorldPos){
LeftEncoder.resetPosition();
HorizontalEncoder.resetPosition();
while (YPos < yWorldPos) {
driveControlForwards(yWorldPos - YPos);
//printTask = task(printValues);
// opticalTask = task(opticalValues);
// Wait an amount of seconds, while returning the actual wait time to the variable "m"
//When telling a computer to wait, it may have a load-amount that would result in it yielding earlier or later then the actual time, that's why we do this
int m = wait(milisecondStepTime);
//Gets Values of Encoders
//This gets the position of the sensors (this is local position)
int leftEnc = LeftEncoder.position(degrees);
if(flipLeftEncoder) leftEnc *= -1; // If flipLeft, then multiply value by -1
// int rightEnc = RightEncoder.position(degrees);
// if(flipRightEncoder) rightEnc *= -1; // If flipRight, then multiply value by -1
int horizEnc = HorizontalEncoder.position(degrees);
if(flipHorizontalEncoder) horizEnc *= -1; // If flipHorizontal, then multiply value by -1
// Get the rotation of the inertial sensor
double RobotRotation = InternalSensor.rotation();
if(flipRotations) RobotRotation *= -1;
//Does quicc maths to find out an accurate encoder readings of local position change
//This is for the local position of the robot (THIS IS NOT WORLD POSITION)
double VerticalPosLocal = (leftEnc /*+ rightEnc*/);
double HorizontalPosLocal = horizEnc + (RobotRotation * rotateNegateHorizontalRatio);
//Applies ratio
HorizontalPosLocal *= verticalToHorizontalRatio;
//By getting position - lastposition within 20 miliseconds, this will give us velocity
//Similar to PID alrogithms, this converts position -> Velocity by gettings its derivative through the continuous loop
double YV = VerticalPosLocal - lastVerticalPosLocal;
double XV = HorizontalPosLocal - lastHorizontalPosLocal;
//Do some relatively-complex maths that converts local velocity to world-space velocity. The (m/milisecondStepTime) at the end is a multiplier
//that would scale velocity more appropriately due to computer yields (Line 131 explains) If computer is told to wait 2 second and waits 0.75 instead,
//the multiplier would then scale the velocity to be 0.375 its value (0.75/2 = 0.375)
double XVelocityWorldSpace = (XV * std::cos(getRadians(-RobotRotation)) - YV * std::sin(getRadians(-RobotRotation))) * (m/milisecondStepTime);
double YVelocityWorldSpace = (XV * std::sin(getRadians(RobotRotation)) - YV * std::cos(getRadians(RobotRotation))) * (m/milisecondStepTime);
//This would give us the X and Y position in world space
XPos += XVelocityWorldSpace / posTranslationMultiplier;
YPos += YVelocityWorldSpace / posTranslationMultiplier;
Brain.Screen.printAt(1, 120, "XPOS: %f ", XPos);
Brain.Screen.printAt(1, 140, "YPOS: %f ", YPos);
task::sleep(10);
//This is applied to be utilized 20 miliseconds after
lastVerticalPosLocal = VerticalPosLocal;
lastHorizontalPosLocal = HorizontalPosLocal;
}
}
void flywheelIn(int degrees, int speed){
flywheel.resetPosition();
while(flywheel.rotation(deg) > -1 * degrees){
flywheel.spin(vex::directionType::rev, speed, pct);
}
flywheel.stop(brakeType::hold);
}
void flywheelOut(int degrees, int speed){
flywheel.resetPosition();
while(flywheel.rotation(deg) < degrees){
flywheel.spin(vex::directionType::fwd, speed, pct);
}
flywheel.stop(brakeType::hold);
}
void rolyPolyIn(int degrees, int speed){
intakeRolyPoly.resetPosition();
while(intakeRolyPoly.rotation(deg) > -1 * degrees){
intakeRolyPoly.spin(vex::directionType::rev, speed, pct);
}
intakeRolyPoly.stop(brakeType::hold);
}
void rolyPolyOut(int degrees, int speed){
intakeRolyPoly.resetPosition();
while(intakeRolyPoly.rotation(deg) < degrees){
intakeRolyPoly.spin(vex::directionType::fwd, speed, pct);
}
intakeRolyPoly.stop(brakeType::hold);
}

void turnSlight(){
backRightWheel.spinFor(reverse, 1000, deg);
backLeftWheel.spinFor(forward, 1000, deg);
}

void setleftdrive (vex::directionType type, int percentage) {
  frontLeftWheel.spin(type, percentage, vex::velocityUnits::pct);
  backLeftWheel.spin(type, percentage, vex::velocityUnits::pct);
}

void setrightdrive (vex::directionType type, int percentage) {
  frontRightWheel.spin(type, percentage, vex::velocityUnits::pct);
  backRightWheel.spin(type, percentage, vex::velocityUnits::pct);
}

void indexerToDefault(){
while(indexer.position(deg) > -100){
indexer.spin(vex::directionType::rev, 50, pct);
}
indexer.stop(brakeType::hold);
}
void indexerShoot(){
while(indexer.position(deg) < 100){
indexer.spin(vex::directionType::fwd, 100, pct);
}
indexer.stop(brakeType::hold);
}
int spinIndexerDefault(){
indexer.spin(fwd, 200, pct);
wait(450,msec);
indexer.stop();
return 0;
}
int spinIndexerShoot(){
indexer.spin(reverse, 200, pct);
wait(450,msec);
indexer.stop();
return 0;
}
void rolyPolyInFlywheelOutIndexerShoot(int rpspeed, int fwspeed, int rlspeed){
intakeRolyPoly.resetPosition();
flywheel.resetPosition();
roller.resetPosition(); //put set velocity in loop if this doesn't work
intakeRolyPoly.setVelocity(rpspeed, percent);
flywheel.setVelocity(fwspeed,percent);
roller.setVelocity(rlspeed, percent);
//while(true){
intakeRolyPoly.spinFor(reverse, 100, turns, false); //false is nonblocking
flywheel.spinFor(fwd, 100, turns, false);
roller.spinFor(forward, 3000, degrees, false);
//intakeRolyPoly.spin(vex::directionType::rev, rpspeed, pct);
//flywheel.spin(vex::directionType::fwd, fwspeed, pct);
//roller.spin(vex::directionType::fwd, rlspeed, pct);
wait(6000,msec);
//indexer.spin(vex::directionType::rev, 50, pct);
indexer.spinFor(reverse, 91, degrees);
wait(1000, msec);
indexer.spinFor(forward, 91, degrees); //chanGe degrees change blocking/nonblocking (true)
wait(1000, msec);
indexer.spinFor(reverse, 91, degrees);
wait(1000, msec);
indexer.spinFor(forward, 91, degrees);
intakeRolyPoly.stop(brakeType::hold);
flywheel.stop(brakeType::hold);
roller.stop(brakeType::hold);
indexer.stop(brakeType::hold);
//}
//indexer.spin(vex::directionType::fwd, 100, pct);
// intakeRolyPoly.stop(brakeType::hold);
// flywheel.stop(brakeType::hold);
// roller.stop(brakeType::hold);
// indexer.stop(brakeType::hold);
}

int timesPressed = 0;
void flywheelHoldFaster(){
timesPressed++;
if(timesPressed % 2 == 0){
flywheel.stop(brakeType::hold);
}
else{
flywheel.spin(forward, 64, pct);
}
timesPressed = 0;
}
void flywheelHoldSlower(){
timesPressed++;
if(timesPressed % 2 == 0){
flywheel.stop(brakeType::hold);
}
else{
flywheel.spin(forward, 50, pct);
}
timesPressed = 0;
}
/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
void pre_auton(void) {
// Initializing Robot Configuration. DO NOT REMOVE!
vexcodeInit();
//InternalSensor.resetRotation();
LeftEncoder.resetPosition();
HorizontalEncoder.resetPosition();
pneu.set(false);

while (1) {
//printTask = task(printValues);
// opticalTask = task(opticalValues);
// Wait an amount of seconds, while returning the actual wait time to the variable "m"
//When telling a computer to wait, it may have a load-amount that would result in it yielding earlier or later then the actual time, that's why we do this
int m = wait(milisecondStepTime);
pneu.set(false);
//Gets Values of Encoders
//This gets the position of the sensors (this is local position)
int leftEnc = LeftEncoder.position(degrees);
if(flipLeftEncoder) leftEnc *= -1; // If flipLeft, then multiply value by -1
// int rightEnc = RightEncoder.position(degrees);
// if(flipRightEncoder) rightEnc *= -1; // If flipRight, then multiply value by -1
int horizEnc = HorizontalEncoder.position(degrees);
if(flipHorizontalEncoder) horizEnc *= -1; // If flipHorizontal, then multiply value by -1
// Get the rotation of the inertial sensor
double RobotRotation = InternalSensor.rotation();
if(flipRotations) RobotRotation *= -1;
//Does quicc maths to find out an accurate encoder readings of local position change
//This is for the local position of the robot (THIS IS NOT WORLD POSITION)
double VerticalPosLocal = (leftEnc /*+ rightEnc*/) / 2.0;
double HorizontalPosLocal = horizEnc + (RobotRotation * rotateNegateHorizontalRatio);
//Applies ratio
HorizontalPosLocal *= verticalToHorizontalRatio;
//By getting position - lastposition within 20 miliseconds, this will give us velocity
//Similar to PID alrogithms, this converts position -> Velocity by gettings its derivative through the continuous loop
double YV = VerticalPosLocal - lastVerticalPosLocal;
double XV = HorizontalPosLocal - lastHorizontalPosLocal;
//Do some relatively-complex maths that converts local velocity to world-space velocity. The (m/milisecondStepTime) at the end is a multiplier
//that would scale velocity more appropriately due to computer yields (Line 131 explains) If computer is told to wait 2 second and waits 0.75 instead,
//the multiplier would then scale the velocity to be 0.375 its value (0.75/2 = 0.375)
double XVelocityWorldSpace = (XV * std::cos(getRadians(-RobotRotation)) - YV * std::sin(getRadians(-RobotRotation))) * (m/milisecondStepTime);
double YVelocityWorldSpace = (XV * std::sin(getRadians(RobotRotation)) - YV * std::cos(getRadians(RobotRotation))) * (m/milisecondStepTime);
//This would give us the X and Y position in world space
XPos += XVelocityWorldSpace / posTranslationMultiplier;
YPos += YVelocityWorldSpace / posTranslationMultiplier;
Brain.Screen.printAt(1, 120, "XPOS: %f ", XPos);
Brain.Screen.printAt(1, 140, "YPOS: %f ", YPos);
task::sleep(10);
//This is applied to be utilized 20 miliseconds after
lastVerticalPosLocal = VerticalPosLocal;
lastHorizontalPosLocal = HorizontalPosLocal;
InternalSensor.calibrate();
while (InternalSensor.isCalibrating()){
wait(3000, msec);
}
gyroTask = task(gyroReturn);
//printTask = task(printValues);
//resetting motors
frontLeftWheel.resetPosition();
frontRightWheel.resetPosition();
backLeftWheel.resetPosition();
backRightWheel.resetPosition();
intakeRolyPoly.resetPosition();
indexer.resetPosition();
flywheel.resetPosition();
// All activities that occur before the competition starts
// Example: clearing encoders, setting servo positions, ...
}
}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
void autonomous(void) {
// ..........................................................................
// Insert autonomous user code here.
// ..........................................................................
//task opticalTask = opticalValues;
// //port 2 - blue shooting 2 disks
// driveControlForwards(-4); //backwards
// //driveControlTurnLeft(1); //right
// driveControlStrafe(10);
// driveControlStrafe(-10);
// rolyPolyInFlywheelOut(100,100,100);
// driveControlStrafe(-10);
// driveControlStrafe(10);


//driveControlForwards(


//strafe  
//pneu.set(0);
// wait(100, msec);
// //pneu.set(0);
// wait(100,msec);
// driveControlStrafe(24);
// driveControlForwards(5);
// wait(100);
// roller.spinTo(100, degrees);
// driveControlForwards(-4);
// driveControlStrafe(-20);


// backRightWheel.spinFor(reverse, 1000, deg);
// //turnSlight();
// frontLeftWheel.stop();
// frontRightWheel.stop();
// backLeftWheel.stop();
// backRightWheel.stop();


//rolyPolyInFlywheelOutIndexerShoot(0, 75, 0);
//wait(200, msec);
//indexer.resetPosition()                                                                                                                                                                                                                                                                                                                                                                                                             ;
//rolyPolyInFlywheelOutIndexerShoot(0, 75, 0);


//skills
pneu.set(false);
driveControlForwards(2.5);
roller.spinTo(100, degrees);
driveControlForwards(-2);
driveControlTurnGyro(10);
backRightWheel.spinFor(fwd, 850, deg);
frontLeftWheel.stop();
frontRightWheel.stop();
backLeftWheel.stop();
backRightWheel.stop();
//turnSlight();
rolyPolyInFlywheelOutIndexerShoot(0, 75, 0);
wait(200, msec);
indexer.resetPosition()                                                                                                                                                                                                                                                                                                                                                                                                             ;
rolyPolyInFlywheelOutIndexerShoot(0, 75, 0);
pneu.set(true);

//MATCH AUTON - PORT 1 - DOES NOTHING

//MATCH AUTON - PORT 2 - ROLLER --> RIGH TURN --> SHOOT LOW GOAL
// pneu.set(false);
// driveControlForwards(2.5);
// roller.spinTo(80, degrees);
// driveControlForwards(-1);
// //pneu.set(true);
// //driveControlTurnGyro(10);
// backRightWheel.spinFor(fwd, 1000, deg);
// frontLeftWheel.stop();
// frontRightWheel.stop();
// backLeftWheel.stop();
// backRightWheel.stop();
// //turnSlight();
// rolyPolyInFlywheelOutIndexerShoot(0, 50, 0);




//SKILLS AUTON - PORT 3 - ROLLER --> --> ROLLER --> LOW GOAL?
// pneu.set(false);
// //rolyPolyInFlywheelOutIndexerShoot(0, 0, 0); //68 fw speed
// //wait(1000, msec);
// driveControlForwards(1);
// roller.spinTo(200, degrees);
// driveControlForwards(-3);
// // // //pneu.set(true);
// //backRightWheel.setVelocity(70,percent);
// //backRightWheel.spinFor(fwd, 1220, degrees);
// //backRightWheel.spinFor(fwd, 650, degrees);
// //turning(90);
// driveControlForwards(-12);
// driveControlStrafe(-25);
// driveControlTurnGyro(-10.2);
// frontLeftWheel.stop();
// frontRightWheel.stop();
// backLeftWheel.stop();
// backRightWheel.stop();
// wait(200, msec);




// // frontLeftWheel.stop();
// // frontRightWheel.stop();
// // backLeftWheel.stop();
// // backRightWheel.stop();
// // wait(200, msec);
// roller.spinTo(700, degrees);


//test
// pneu.set(false);
// driveControlForwards(4.5);
// roller.spinTo(150, degrees);
// wait(100,msec);
// driveControlForwards(-15);
// wait(100, msec);
// driveControlTurnGyro(60);


// // wait(100, msec);
// // driveControlForwards(13);
// // wait(100,msec);
// // roller.spinTo(120, degrees);
// // wait(100, msec);
// // driveControlForwards(-5);
// // driveControlTurnGyro(10);
// // //turnSlight();
// // //rolyPolyInFlywheelOutIndexerShoot(0, 75, 0);
// // wait(200, msec);
// // //indexer.resetPosition()                                                                                                                                                                                                                                                                                                                                                                                                             ;
// // //rolyPolyInFlywheelOutIndexerShoot(0, 75, 0);
// // driveControlForwards(2);
// // pneu.set(true);
// //driveControlTurnGyro(50);


}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
int intakeSpeed = 200;
int rolyPolySpeed = 50;
int rollerSpeed = 200;
int indexerSpeed = 5;
// User control code here, inside the loop
// void flywheelHold(){
//   flywheel.spin(vex::directionType::fwd, flywheelSpeed, pct);
// }
void usercontrol(void) {
//Controller1.ButtonR1.pressed(flywheelHoldFaster);
//Controller1.ButtonR2.pressed(flywheelHoldSlower);
//vex::digital_out pneu = vex::digital_out(Brain.ThreeWirePort.B);
pneu.set(false);
wait(100,msec);
double turnimportance = 0.5;
while(1){

int fwdcont = Controller1.Axis3.position(percent);
int sidecont = Controller1.Axis4.position(percent);
int turncont = Controller1.Axis1.position(percent);

frontLeftWheel.spin(reverse, fwdcont -sidecont- turncont, velocityUnits::pct);
backLeftWheel.spin(reverse, fwdcont+sidecont+turncont, velocityUnits::pct);
frontRightWheel.spin(reverse, fwdcont+sidecont- turncont, velocityUnits::pct);
backRightWheel.spin(reverse, fwdcont-sidecont+turncont, velocityUnits::pct);


// // setleftdrive (vex::directionType::fwd, Controller1.Axis3.value());
// // setrightdrive (vex::directionType::fwd, Controller1.Axis3.value());

// // double turnval = Controller1.Axis1.position(percent);
// // double fwdval = Controller1.Axis3.position(percent);
// // double turnvolts = turnval;
// // double fwdvolts = fwdval;
// frontLeftWheel.spin(fwd, Controller1.Axis3.position() + Controller1.Axis1.position(), voltageUnits::volt);
// backLeftWheel.spin(fwd, Controller1.Axis3.position() + Controller1.Axis1.position(), voltageUnits::volt);
// frontRightWheel.spin(fwd, Controller1.Axis3.position() - Controller1.Axis1.position(), voltageUnits::volt);
// backRightWheel.spin(fwd, Controller1.Axis3.position() - Controller1.Axis1.position(), voltageUnits::volt);


// if(abs(Controller1.Axis3.position(percent)) > 5 || abs(Controller1.Axis1.position((percent)))> 5){
// frontLeftWheel.spin(reverse, Controller1.Axis3.position(percent) + Controller1.Axis1.position(percent)/2, velocityUnits::pct);
// backLeftWheel.spin(reverse, Controller1.Axis3.position(percent) + Controller1.Axis1.position(percent)/2, velocityUnits::pct);
// frontRightWheel.spin(reverse, Controller1.Axis3.position(percent) + Controller1.Axis1.position(percent)/2, velocityUnits::pct);
// backRightWheel.spin(reverse, Controller1.Axis3.position(percent) + Controller1.Axis1.position(percent)/2, velocityUnits::pct);
// }
// else if(abs(Controller1.Axis4.position()) > 15){
// frontLeftWheel.spin(reverse, Controller1.Axis4.position(percent), velocityUnits::pct);
// backLeftWheel.spin(fwd, Controller1.Axis4.position(percent), velocityUnits::pct);
// frontRightWheel.spin(fwd, Controller1.Axis4.position(percent), velocityUnits::pct);
// backRightWheel.spin(reverse, Controller1.Axis4.position(percent), velocityUnits::pct);
// }
//  else if(Controller1.ButtonRight.pressing()){
//  frontLeftWheel.spin(fwd, 100, velocityUnits::pct);
//  backLeftWheel.spin(reverse, 100, velocityUnits::pct);
//  frontRightWheel.spin(reverse, 100, velocityUnits::pct);
//  backRightWheel.spin(fwd, 100, velocityUnits::pct);
//  }
// else {
// frontLeftWheel.stop(brakeType::hold);
// frontRightWheel.stop(brakeType::hold);
// backLeftWheel.stop(brakeType::hold);
// backRightWheel.stop(brakeType::hold);
// }
if(Controller1.ButtonX.pressing()){
thread myThread = thread(spinIndexerDefault);
}
else if(Controller1.ButtonA.pressing()){
thread myThread2 = thread(spinIndexerShoot);
}
else{
indexer.stop();
}


if(Controller1.ButtonDown.pressing()){
flywheel.stop(brakeType::hold);
}
else{
Controller1.ButtonR1.pressed(flywheelHoldFaster);
Controller1.ButtonR2.pressed(flywheelHoldSlower);
}



// if(Controller1.ButtonUp.pressed()){
//   flywheelSpeed
// }
// else if(Controller1.ButtonLeft.pressing()){
//   thread myThread2 = thread(spinIndexerShoot);
// }
// else{
//   indexer.stop();
// }


if(Controller1.ButtonL1.pressing()){
intakeRolyPoly.spin(forward, intakeSpeed, pct);
roller.spin(forward, rollerSpeed, pct);
}
else if(Controller1.ButtonL2.pressing()){
intakeRolyPoly.spin(reverse, intakeSpeed, pct);
roller.spin(reverse, rollerSpeed, pct);
}
else{
intakeRolyPoly.stop();
roller.stop();
}


if(Controller1.ButtonA.pressing()){
spinIndexerShoot();
}
// else if(Controller1.ButtonX.pressing()){
//   spinIndexerDefault();
// }
else{
indexer.stop();
}
// if(Controller1.ButtonRight.pressing()){
// pneu.set(true);
// }
// else {
// pneu.set(false);
// }


if(Controller1.ButtonRight.pressing()){
pneu = 1;
}
else {
pneu = 0;
}


}
}
//
// Main will set up the competition functions and callbacks.
//
int main() {
// Set up callbacks for autonomous and driver control periods.
Competition.autonomous(autonomous);
Competition.drivercontrol(usercontrol);
// Run the pre-autonomous function.
pre_auton();
// Prevent main from exiting with an infinite loop.
while (true) {
wait(100, msec);
}
}



