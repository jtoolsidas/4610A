using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor frontLeftWheel;
extern motor frontRightWheel;
extern motor backLeftWheel;
extern motor backRightWheel;
extern optical Optical2;
extern inertial InternalSensor;
extern rotation HorizontalEncoder;
extern rotation LeftEncoder;
extern motor intakeRolyPoly;
extern motor flywheel;
extern motor indexer;
extern digital_out pneu;
extern motor roller;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );