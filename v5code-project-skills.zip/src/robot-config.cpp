#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
motor frontLeftWheel = motor(PORT20, ratio18_1, false);
motor frontRightWheel = motor(PORT17, ratio18_1, true);
motor backLeftWheel = motor(PORT8, ratio18_1, false);
motor backRightWheel = motor(PORT1, ratio18_1, true);
optical Optical2 = optical(PORT21);
inertial InternalSensor = inertial(PORT19);
rotation HorizontalEncoder = rotation(PORT10, true);
rotation LeftEncoder = rotation(PORT7, true);
motor intakeRolyPoly = motor(PORT6, ratio18_1, false);
motor flywheel = motor(PORT4, ratio18_1, false);
motor indexer = motor(PORT15, ratio18_1, false);
digital_out pneu = digital_out(Brain.ThreeWirePort.H);
motor roller = motor(PORT9, ratio18_1, false);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}